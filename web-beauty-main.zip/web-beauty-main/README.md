# web-beauty

A very nice site to feel the life
try it [here](https://semant.is-a.dev/web-beauty)

Star it if you like it :D

# Whats in it?

Nothing much, just a nice little rainbow background,
some nice music and sounds, and a few pop ups

# inspiration

inspired by theannoyingsite.com

# Contribution?

Just make a pr to contribute :D
